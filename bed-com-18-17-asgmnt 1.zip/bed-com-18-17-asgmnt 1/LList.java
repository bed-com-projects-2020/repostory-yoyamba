package chifundo;

public class LList implements List { // Linked list
	private Link head; // Pointer to list header
	private Link tail; // Pointer to last Object in list
	protected Link curr; // Position of current Object
	private int count;

	LList(int sz) {
		setup();
	} // Constructor

	LList() {
		setup();
		count = 0;
	} // Constructor

	private void setup() // allocates leaf node
	{
		tail = head = curr = new Link(null);
	}

	public void setFirst() {
		curr = head;
	}

	public void next() {
		if (curr != null)
			curr = curr.next();
	}

	public void prev() { // Move to previous position
		Link temp = head;
		if ((curr == null) || (curr == head)) // No prev
		{
			curr = null;
			return;
		} // so return
		while ((temp != null) && (temp.next() != curr))
			temp = temp.next();
		curr = temp;
	}

	public Object currValue() { // Return current Object
		if (!isInList() || this.isEmpty())
			return null;
		return curr.next().element();
	}

	public boolean isEmpty() // True if list is empty
	{
		return head.next() == null;
	}

	// Insert Object at current position
	public void insert(Object it) {
		assert curr != null : "No current element";
		curr.setNext(new Link(it, curr.next()));
		if (tail == curr) // Appended new Object
			tail = curr.next();
		count++;
	}

	public Object remove() { // Remove/return curr Object
		if (!isInList() || this.isEmpty())
			return null;
		Object it = curr.next().element(); // Remember value
		if (tail == curr.next())
			tail = curr; // Set tail
		curr.setNext(curr.next().next()); // Cut from list
		count--;
		return it; // Return value
	}

	@Override
	public void clear() {// Your assignment

		
		curr = head.setNext(null);
		curr = head = tail = new Link(null); 
		count = 0;
		

	}

	@Override
	public void append(Object item) {// Your assignment
		Link link = new Link(item, null);
		
		tail = tail.setNext(link);
		count++;

	}

	@Override
	public int length() {// Your assignment
		
	System.out.println("The length is : "+count);
			
		return count;
	}
	

	@Override
	public void setPos(int pos) {// Your Assignment
		
			assert (pos>=0) && (pos<=count) : "Position out of range";
			curr = head;
			for (int i=0; i<pos; i++){ 
				curr = curr.next();
			}
			System.out.println("The value at current position is : "+curr.element());

	}

	@Override
	public void setValue(Object val) {
		assert isInList() : "Invalid current position";
		curr.setElement(val);
	}

	@Override
	public boolean isInList() {
		if (curr != null)
			return curr != head;
		return false;
	}

	@Override
	public void print() {// Your Assignment
		curr = head.next();
		while(curr != null){
			System.out.println(curr.element());
			curr = curr.next();
			
		}
	}
} // Linked list class
